/* BaseCoverageCalc.cpp by TJ Butler
 * last modified 07/14/2015
*/

#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <vector>
#include <map>

using namespace std;

string basecoverage(string curChrom, ofstream& outfile, map<double,int>& coverageEstimates, double& coverageMT){
	string chromNumber = curChrom;
	double curTotal = 0;
	double basesFound = 0;
	int curCoverage = 0;
	double curBaseNo = 0;
	while((curChrom.compare(chromNumber) == 0) && cin.good()){
		cin >> curBaseNo >> curCoverage;
		curTotal += curCoverage;
		basesFound++;
		//Read in a new line to set up for next loop 
		//iteration
		cin >> chromNumber;
	}
	//Update coverageEstimates
	if ((curChrom.compare("MT") != 0) && (curChrom.compare("X") != 0) && (curChrom.compare("Y")!= 0)){
		coverageEstimates.insert(pair<double,int>(((double)curTotal/basesFound),atoi(curChrom.c_str())));
	}
	else coverageMT = (double)(curTotal/basesFound);
	return chromNumber;
}

int main(int argc, char** argv){
	if (argc != 3){
		cout << "\n\n";
		cout << "BaseCoverageCalc usage: " << argv[0] << " </working/dir/> <bamFileLabel>\n\n";
		cout << "*This program finds the average depth of each chromosome as a whole.\n";
		cout << "/working/dir/ is complete path to a working directory\n";
		cout << "If current directory is desired, type \"./\"\n\n";
		cout << "*This program utilizes samtools' depth utility, piped as stdin.\n";
		cout << "8/9/13: removed X and Y from average coverage calculation\n";
		cout << "11/13/13: added necessary working directory option\n\n";
		return 1;
	}
	string curChrom = "";
	map<double,int> coverageEstimates;
	cin >> curChrom;
	
	//Build the unique outfile name for each chromosome, step by step
	string outfileName = argv[1];
	outfileName += argv[2];
	outfileName += "MTData.txt";
	ofstream outfile;
	outfile.open(outfileName.c_str());

	//For entire file, go through each chromosome
	//and stop when curChrom == MT, and then perform loop
	//one more time
	double MTcoverage = 0;
	//cout << cin.good();
	while ((curChrom[0] != 'M') && cin.good()){
		curChrom = basecoverage(curChrom,outfile,coverageEstimates,MTcoverage);
	}
	//Need to do last coverage calculation for mtDNA
	curChrom = basecoverage(curChrom,outfile,coverageEstimates,MTcoverage);
	double coverageAverage = 0;
	for (map<double,int>::iterator it = coverageEstimates.begin(); it != coverageEstimates.end(); ++it){
		coverageAverage += it->first;
	}
	map<double,int>::iterator secondLowCoverageIt = coverageEstimates.begin();
	map<double,int>::iterator lowCoverageIt = secondLowCoverageIt++;
	map<double,int>::iterator secondHighCoverageIt = --coverageEstimates.end();
	map<double,int>::iterator highCoverageIt = secondHighCoverageIt--;
	coverageAverage = coverageAverage - (lowCoverageIt->first) - (highCoverageIt->first);
	coverageAverage /= 20;
	double mtCopyNoAvg = 2*MTcoverage/(coverageAverage);
	double mtCopyNoLow = 2*MTcoverage/(secondHighCoverageIt->first);
	double mtCopyNoHigh = 2*MTcoverage/(secondLowCoverageIt->first);
	outfile << "mt_copy_number_avg: " << mtCopyNoAvg << endl;
	outfile << "mt_copy_number_low: " << mtCopyNoLow << endl;
	outfile << "mt_copy_number_high: " << mtCopyNoHigh << endl;
	outfile << "mt_coverage: " << MTcoverage << endl;
	outfile << "autosomal_coverage: " << coverageAverage << endl;
	outfile << "chromNo\tavgCoverage\n";
	for (map<double,int>::iterator it=coverageEstimates.begin(); it != coverageEstimates.end(); ++it){
		outfile << it->second << '\t' << it->first << endl;
	}
	outfile.close();
}
