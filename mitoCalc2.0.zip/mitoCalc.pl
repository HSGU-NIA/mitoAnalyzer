#! /usr/bin/perl -w
use warnings;
use strict;

print "\nmitoCalc 1.0 -- Estimating mitochondrial DNA copy number from sequencing data\n";
print "(c) 2015 TJ Butler and Jun Ding\n\n";

my $note = "Note:
<in.bam> is the individual bam file to be analyzed, and it can be in the format of /Path/To/bam/File/ID.bam. \"ID\" will be used as the identifier for output files.
<workDir> is the working directory, where the intermediate files and final output will be generated.
<BaseCoverageCalcCommand> is the path to the executable \"BaseCoverageCalc\" in the format of /Path/To/Command/BaseCoverageCalc\n"; 

die "Usage: perl mitoCalc.pl <in.bam> <workDir> <BaseCoverageCalcCommand>\n$note" unless ($#ARGV == 2);
my ($filename, $workDir, $BaseCoverageCalc) = @ARGV;

`mkdir -p $workDir`;

my (@bamLabels) = split(/\//,$filename);
my $lastSplit = $bamLabels[$#bamLabels];
my (@fullBamName) = split(/\./,$lastSplit);
my $bamNumber = $fullBamName[0];
my $afterFilterName = "filtered".$bamNumber;

my $filterCommand = "samtools view -b -q 20 -F 0x0704 $filename -o $workDir/$afterFilterName.bam";
print "$filterCommand\n";
system($filterCommand);
my $depthCommand = "samtools depth -aa $workDir/$afterFilterName.bam | $BaseCoverageCalc $workDir/ $bamNumber";
print "$depthCommand\n";
system($depthCommand);

my $rmCommand = "rm -f $workDir/$afterFilterName.bam";
print "$rmCommand\n";
system($rmCommand);

