/*
 *  Copyright (C) 2010  Regents of the University of Michigan
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <map>

#include "SamFile.h"
#include "PileupWithGenomeReference.h"
#include "PileupElementSummary.h"
#include "PileupElementBaseQual.h"
#include "tclap/CmdLine.h"
#include "tclap/Arg.h"
#include "InputFile.h"

int main(int argc, char ** argv)
{
    try 
    {
        std::string desc = "Example:\n\
mitoCaller -b bamFile.with.mtDNA.reads.only.bam -r reference.genome -m > mtDNA.calls.output.summary \n\
mitoCaller takes in a BAM file (with only mtDNA sequence reads) and a genome reference file to return the mtDNA variant calls (refer to the annotation file for details on the output). \n";
   			
        std::string version = "1.0";
        TCLAP::CmdLine cmd(desc, ' ', version);
        TCLAP::ValueArg<std::string> argInputBAMFileName("b", "bam", "BAM file", true, "", "string");
        TCLAP::ValueArg<std::string> argRefSeqFileName("r", "reference", "Reference Sequence file", true, "", "string");
        TCLAP::ValueArg<std::string> argInputVCFFileName("i", "inputvcf", "VCF file listing the loci of interest (can be gzipped), bam index file is automatically assumed to be in the same location as the bam file.", false, "", "string");
        TCLAP::ValueArg<std::string> argOutputVCFFileName("v", "ouputvcf", "VCF file - if the extension is .gz, the written file will be a gzip file, (default is STDOUT)", false, "-", "string");
        TCLAP::SwitchArg argAddDelAsBase("d", "adddelasbase", "Adds deletions as base", cmd, false);
        TCLAP::SwitchArg argMito("m", "mito", "Calls mitochondrial DNA variants (this option is mandatory for mito-analysis)", cmd, false);

        cmd.add(argInputBAMFileName);
        cmd.add(argRefSeqFileName);
        cmd.add(argInputVCFFileName);
        cmd.add(argOutputVCFFileName);
        cmd.parse(argc, argv);

        //std::cout << "Running mitoCaller version " << version << std::endl; 
        std::string inputBAMFileName = argInputBAMFileName.getValue();
        //std::cout << "bam file                : " << inputBAMFileName << std::endl; 
        std::string refSeqFileName = argRefSeqFileName.getValue();	
        //std::cout << "reference sequence file : " << argRefSeqFileName.getValue() << std::endl; 
        std::string inputVCFFileName = argInputVCFFileName.getValue();

        bool mitoIndicator = argMito.getValue();

        if(mitoIndicator)
        {
            bool inputVCFFileIsGZipped = false;
            bool outputVCFFileIsGZipped = false;
            std::string outputVCFFileName = argOutputVCFFileName.getValue();
            PileupWithGenomeReference<PileupElementSummary> pileup(1024, refSeqFileName, argAddDelAsBase.getValue(), inputVCFFileIsGZipped, outputVCFFileIsGZipped);
            pileup.processFile(inputBAMFileName, outputVCFFileName);
	    //   Pileup<PileupElementSummary> pileup(refSeqFileName);
            
            //   pileup.processFile(inputBAMFileName);
        }
        else
        {
            if (inputVCFFileName != "")
            {
                std::cout << "input VCF file          : " << inputVCFFileName << std::endl; 
            }
            std::string outputVCFFileName = argOutputVCFFileName .getValue();
            
            bool inputVCFFileIsGZipped = false;
            if (outputVCFFileName.length()>3 && (outputVCFFileName.substr(outputVCFFileName.length()-3, 3) == ".gz"))
            {
                inputVCFFileIsGZipped = true;
            }
            else
            {
                inputVCFFileIsGZipped = false;
            }
            
            bool outputVCFFileIsGZipped = false;
            if (outputVCFFileName.length()>3 && (outputVCFFileName.substr(outputVCFFileName.length()-3, 3) == ".gz"))
            {
                std::cout << "output VCF file         : " << outputVCFFileName << " (gzip)" << std::endl; 
                outputVCFFileIsGZipped = true;
            }
            else if (outputVCFFileName=="-")
            {
                std::cout << "output VCF file         : STDOUT" << std::endl; 
                outputVCFFileIsGZipped = false;
            }
            else
            {
                std::cout << "output VCF file         : " << outputVCFFileName << std::endl; 
                outputVCFFileIsGZipped = false;
            }
            
            std::cout << "add deletions as bases  : " << (argAddDelAsBase.getValue()? "yes" : "no") << std::endl; 
            
            PileupWithGenomeReference<PileupElementBaseQual> pileup(1024, refSeqFileName, argAddDelAsBase.getValue(), inputVCFFileIsGZipped, outputVCFFileIsGZipped);
            
            //process file with index    	
            if (inputVCFFileName != "")
            {
                pileup.processFile(inputBAMFileName, inputVCFFileName, outputVCFFileName);
            }
            else
            {
                pileup.processFile(inputBAMFileName, outputVCFFileName);
            }
        }
    }
    catch (TCLAP::ArgException &e) 
    {
        std::cerr << "error: " << e.error() << " for arg " << e.argId() << std::endl;
        abort();
    }

    return(0);
}
