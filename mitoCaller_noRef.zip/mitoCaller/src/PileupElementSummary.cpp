/*
 *  Copyright (C) 2010  Regents of the University of Michigan
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdexcept>
#include <stdint.h>
#include <stdarg.h>
#include <math.h>

#include "PileupElementSummary.h"
#include "GenomeSequence.h"
#include "BaseAsciiMap.h"

int indexGenotype(std::string genotype);
std::string backindexGenotype(int index);
std::string backToAlleleGenotype(std::string genotype);
void estimateAlleFreq(int myIndex, int * myCountAlleles, int * indVector, double * alleFreq, double & llk);
int checkStrand(std::string predictGeno, int * myStrandInd);
int summaryStrand(int * myStrandInd);

//double computeLLK(double error, int * myCountAlleles, double * alleFreq);
double * alloc_vector(int cols);
void free_vector(double * vector,int cols);
double ** alloc_matrix(int rows,int cols);
void free_matrix(double ** matrix,int rows,int cols);
double ** make_simplex(double * point,int dim);
void simplex_extremes(double *fx,int dim,int & ihi,int & ilo,int & inhi);
void evaluate_simplex(int * indVector,double ** simplex,int dim,double * fx,double (* func)(int *,double *,int));
void simplex_bearings(double ** simplex,int dim,double * midpoint,double * line,int ihi);
int update_simplex(int * indVector,double * point,int dim,double & fmax,double * midpoint,double * line,double scale,double (* func)(int *,double *,int));
void contract_simplex(int * indVector,double ** simplex,int dim,double * fx,int ilo,double (* func)(int *,double *,int));
int check_tol(double fmax,double fmin,double ftol);
double amoeba(int * indVector,double * point,int dim,double (* func)(int *,double *,int),double tol);
double function(int * indVector, double * theda, int dim);
void assignAlleFreq(int * indVector, double * point, int dim, double * alleFreq);
void transformTheda(double * theda, double * transformedTheda, int dim, int * indVector);
void convertBasesToInt(char * myBases, int myIndex);
int switchBasestoInt(char charbase);
void convertQualitiesToError(int8_t * myQualities, int myIndex);

#define Max_Coverage 200000
#define ZEPS 1e-10
#define DepthThreshold 10
#define QSThreshold 20
int myBasesInt[Max_Coverage];
double myError[Max_Coverage];  
int myIndexGlobal;
int loop = 0;
double myErrorThreshold = pow(10, -QSThreshold/10.0)/3.0;

PileupElementSummary::PileupElementSummary()
    : PileupElement(),
      myBases(NULL),
      //      myMapQualities(NULL),
      myQualities(NULL),
      myStrands(NULL),
      //      myCycles(NULL),
      //      myGLScores(NULL),
      myAllocatedSize(0),
      myIndex(-1),
      myAddDelAsBase(false),
      myRefSeq(NULL),
      myVcfOutFile(NULL)
{
    myAllocatedSize = 1024;
    myBases = (char*)malloc(myAllocatedSize + 1);
    //    myMapQualities = (int8_t*)malloc(myAllocatedSize * sizeof(int8_t));
    myQualities = (int8_t*)malloc(myAllocatedSize * sizeof(int8_t));
    myStrands = (char*)malloc(myAllocatedSize + 1);
    //    myCycles = (int8_t*)malloc(myAllocatedSize * sizeof(int8_t));
    //    myGLScores = (int16_t*)malloc(myAllocatedSize * sizeof(int16_t));

    if((myBases == NULL ) 
       //   || (myMapQualities == NULL)
       || (myQualities == NULL)
       || (myStrands == NULL))
       //   || (myCycles == NULL)
       //   || (myGLScores == NULL))
    {                     
        // TODO, check for malloc failures.
        std::cerr << "Failed Memory Allocation\n";
    }
    reset();
}                         

PileupElementSummary::PileupElementSummary(bool addDelAsBase)
    : PileupElement(),
      myBases(NULL),
  //      myMapQualities(NULL),
      myQualities(NULL),
      myStrands(NULL),
  //      myCycles(NULL),
  //      myGLScores(NULL),
      myAllocatedSize(0),
      myIndex(-1),
      myAddDelAsBase(addDelAsBase),
      myRefSeq(NULL),
      myVcfOutFile(NULL)
{
    myAllocatedSize = 1024;
    myBases = (char*)malloc(myAllocatedSize + 1);
    //    myMapQualities = (int8_t*)malloc(myAllocatedSize * sizeof(int8_t));
    myQualities = (int8_t*)malloc(myAllocatedSize * sizeof(int8_t));
    //    myGLScores = (int16_t*)malloc(myAllocatedSize * sizeof(int16_t));
    myStrands = (char*)malloc(myAllocatedSize + 1);
    //    myCycles = (int8_t*)malloc(myAllocatedSize * sizeof(int8_t));
    if((myBases == NULL ) 
       //   || (myMapQualities == NULL)
       || (myQualities == NULL)
       || (myStrands == NULL))
       //   || (myCycles == NULL)
       //   || (myGLScores == NULL))
    {                     
        // TODO, check for malloc failures.
        std::cerr << "Failed Memory Allocation\n";
    }       
    reset();              
}  
                          
PileupElementSummary::PileupElementSummary(const PileupElementSummary& q)
    : PileupElement(),    
      myBases(NULL),      
  //      myMapQualities(NULL),
      myQualities(NULL), 
      myStrands(NULL),    
  //      myCycles(NULL),    
  //      myGLScores(NULL), 
      myAllocatedSize(0), 
      myIndex(-1),
      myRefSeq(NULL),
      myVcfOutFile(NULL)
{                         
    myAllocatedSize = 1024;
    myBases = (char*)malloc(myAllocatedSize + 1);
    //    myMapQualities = (int8_t*)malloc(myAllocatedSize * sizeof(int8_t));
    myQualities = (int8_t*)malloc(myAllocatedSize * sizeof(int8_t));
    myStrands = (char*)malloc(myAllocatedSize + 1);
    //    myCycles = (int8_t*)malloc(myAllocatedSize * sizeof(int8_t));
    //    myGLScores = (int16_t*)malloc(myAllocatedSize * sizeof(int16_t));
    myAddDelAsBase = q.myAddDelAsBase;
    if((myBases == NULL ) 
       //       || (myMapQualities == NULL)
       || (myQualities == NULL)
       || (myStrands == NULL))
       //       || (myCycles == NULL)
       //       || (myGLScores == NULL))
    {
        // TODO, check for malloc failures.
        std::cerr << "Failed Memory Allocation\n";
    }
    reset();
}

PileupElementSummary::~PileupElementSummary()
{
    if(myBases != NULL)
    {
        free(myBases);
        myBases = NULL;
    }
    //    if(myMapQualities != NULL)
    //    {
    //        free(myMapQualities);
    //        myQualities = NULL;
    //    }
    if(myQualities != NULL)
    {
        free(myQualities);
        myQualities = NULL;
    }
    
    if(myStrands != NULL)
    {
        free(myStrands);
        myStrands = NULL;
    }
    /*
    if(myCycles != NULL)
    {
        free(myCycles);
        myCycles = NULL;
    }
    if(myGLScores != NULL)
    {
        free(myGLScores);
        myGLScores = NULL;
    }
    */
}

void PileupElementSummary::computeGLScores(int index, int16_t* GLScores, char* bases, int8_t* baseQualities)
{
    int base;
    double result;
    for (int genotype=0; genotype<=9; ++genotype)
    {
    	result = 0;
        for (int i=0; i<=myIndex; ++i)
    	{
            switch(bases[i])
            {
                case 'A':
                    base = 0;
                    break;
                case 'C':
                    base = 1;
                    break;
                case 'G':
                    base = 2;
                    break;
                case 'T':
                    base = 3;
                    break;    			
                default :
                    base = -1;
            }

            if(base!=-1)
            {
                result += myLogGLMatrix[baseQualities[i]][genotype][base];
            }
    	}

    	GLScores[genotype] = -10*result;
    }
}

const char* PileupElementSummary::getRefAllele() 
{ 
    return(myRefAllele.c_str()); 
}
    
// Add an entry to this pileup element.  
void PileupElementSummary::addEntry(SamRecord& record)
{
    // Call the base class:
    PileupElement::addEntry(record);

    if(myRefAllele.empty())
    {
    	genomeIndex_t markerIndex = (*myRefSeq).getGenomePosition(getChromosome(), static_cast<uint32_t>(getRefPosition()+1));
        myRefAllele = (*myRefSeq)[markerIndex];
    }

    // Increment the index
    ++myIndex;
    
    // if the index has gone beyond the allocated space, double the size.
    if(myIndex >= myAllocatedSize)
    {
        char* tempBuffer = (char*)realloc(myBases, myAllocatedSize * 2);
        if(tempBuffer == NULL)
        {
            std::cerr << "Memory Allocation Failure\n";
            // TODO
            return;
        }
        myBases = tempBuffer;
	/*
        int8_t* tempInt8Buffer = (int8_t*)realloc(myMapQualities, myAllocatedSize * 2 * sizeof(int8_t));
        if(tempInt8Buffer == NULL)
        {
            std::cerr << "Memory Allocation Failure\n";
            // TODO
            return;
        }
        myMapQualities = tempInt8Buffer; 
	*/
        int8_t* tempInt8Buffer = (int8_t*)realloc(myQualities, myAllocatedSize * 2 * sizeof(int8_t));
        if(tempInt8Buffer == NULL)
        {
            std::cerr << "Memory Allocation Failure\n";
            // TODO
            return;
        }
        myQualities = tempInt8Buffer;
	
        tempBuffer = (char*)realloc(myStrands, myAllocatedSize * 2);
        if(tempBuffer == NULL)
        {
            std::cerr << "Memory Allocation Failure\n";
            // TODO
            return;
        }
        myStrands = tempBuffer;
        /*
        tempInt8Buffer = (int8_t*)realloc(myCycles, myAllocatedSize * 2 * sizeof(int8_t));
        if(tempInt8Buffer == NULL)
        {
            std::cerr << "Memory Allocation Failure\n";
            // TODO
            return;
        }
        myCycles = tempInt8Buffer; 
        int16_t* tempInt16Buffer = (int16_t*)realloc(myGLScores, myAllocatedSize * 2 * sizeof(int16_t));
        if(tempInt8Buffer == NULL)
        {
            std::cerr << "Memory Allocation Failure\n";
            // TODO
            return;
        }
        myGLScores = tempInt16Buffer;
	*/
        myAllocatedSize = myAllocatedSize * 2;
    }

    Cigar* cigar = record.getCigarInfo();
    
    if(cigar == NULL)
    {
        throw std::runtime_error("Failed to retrieve cigar info from the record.");
    }

    ++myDepth;

    int32_t readIndex = 
        cigar->getQueryIndex(getRefPosition(), record.get0BasedPosition());

    // If the readPosition is N/A, this is a deletion.
    if(readIndex != CigarRoller::INDEX_NA)
    {
        char base = record.getSequence(readIndex);
        //int8_t mapQual = record.getMapQuality();
        //-33 to obtain the PHRED base quality
        char qual = record.getQuality(readIndex);
	qual -= 33;
	/*
        if(qual == UNSET_QUAL)
        {
            qual = ' ';
        }
        else
        {
            qual -= 33;
        }
	*/

        char strand = (record.getFlag() & 0x0010) ? 'R' : 'F';
        //int cycle = strand == 'F' ? readIndex + 1 : record.getReadLength() -  readIndex;
        myBases[myIndex] = base;
        //myMapQualities[myIndex] = mapQual;
        myQualities[myIndex] = qual;
        myStrands[myIndex] = strand;
        //myCycles[myIndex] = cycle;
        myNumAlleles[BaseAsciiMap::baseColor2int[base]]++;
        
	//check the quality score;
	if (qual >= QSThreshold)
	{
            myNumAllelesFilter[BaseAsciiMap::baseColor2int[base]]++;
            ++myDepthFilter;

	    if (BaseAsciiMap::baseColor2int[base] <= 3)
	      // because myStrandInd has a length of 8, only interested in A,C,G,T
	    {
		if (strand == 'F')
		{
		    myStrandInd[BaseAsciiMap::baseColor2int[base]*2] = 1;
		}
		else if (strand == 'R')
		{
		    myStrandInd[BaseAsciiMap::baseColor2int[base]*2+1] = 1;
		}
	    }

	}
    }
    else if(myAddDelAsBase)
    {
        //int8_t mapQual = record.getMapQuality();
        char strand = (record.getFlag() & 0x0010) ? 'R' : 'F';
        myBases[myIndex] = '-';
        //myMapQualities[myIndex] = mapQual;
        myQualities[myIndex] = -1;
        myStrands[myIndex] = strand;
        //myCycles[myIndex] = -1;
    }
    else
    {
        // Do not add a deletion.
        // Did not add any entries, so decrement the index counter since the
        // index was not used.
        --myIndex;
	++myNumDeletes;
    }
}

void PileupElementSummary::analyze()
{
    if(getRefPosition() != UNSET_POSITION && myIndex != -1)
    {
        char tempCStr[11];
	std::string tempStr;

	// std::cout << getChromosome() << "\t" << getRefPosition() + 1 
        //          << "\tRefBase:" << myRefAllele.c_str()
        //          << "\tDepth:" << myDepth;

	tempStr.append(getChromosome());
	tempStr.append("\t");
	sprintf(tempCStr, "%d", getRefPosition()+1 );
	tempStr.append(tempCStr);
	tempStr.append("\tRefBase:");
	tempStr.append(getRefAllele());
	tempStr.append("\tDepth:");
	sprintf(tempCStr, "%d", myDepth);
	tempStr.append(tempCStr);

        for(int i = 0; i <= BaseAsciiMap::baseXIndex; i++)
        {
	    //std::cout << "\t" << BaseAsciiMap::int2base[i] 
            //            << ":" << myNumAlleles[i];
	  tempStr.append("\t");
	  sprintf(tempCStr, "%c", BaseAsciiMap::int2base[i]);
	  tempStr.append(tempCStr);
	  tempStr.append(":");
	  sprintf(tempCStr, "%d", myNumAlleles[i]);
	  tempStr.append(tempCStr);
        }
        //std::cout << "\tDel:" << myNumDeletes;
	tempStr.append("\tDel:");
	sprintf(tempCStr, "%d", myNumDeletes);
	tempStr.append(tempCStr);

	tempStr.append("\tDepthFilter:");
	sprintf(tempCStr, "%d", myDepthFilter);
	tempStr.append(tempCStr);

        for(int i = 0; i <= BaseAsciiMap::baseXIndex; i++)
        {
	    //std::cout << "\t" << BaseAsciiMap::int2base[i] 
            //            << ":" << myNumAlleles[i];
	  tempStr.append("\t");
	  sprintf(tempCStr, "%c", BaseAsciiMap::int2base[i]);
	  tempStr.append(tempCStr);
	  tempStr.append(":");
	  sprintf(tempCStr, "%d", myNumAllelesFilter[i]);
	  tempStr.append(tempCStr);
        }

	//print out strand indicators;
        for(int i = 0; i <= 7; i++)
        {
	  tempStr.append("\t");
	  sprintf(tempCStr, "%d", myStrandInd[i]);
	  tempStr.append(tempCStr);
        }

	// add by Jun Ding to call mitochondrial variants
        int baseRefAllele;
	char myCharRefAllele;
	myCharRefAllele = myRefAllele.at(0);
	baseRefAllele = switchBasestoInt(myCharRefAllele);
	//std::cout << "\tRefBase:" << baseRefAllele << "\n";

	int NumNonZeroAlleles = 0;
	int myCountAlleles[4];
	int NonZeroAlleles[4];
	//int NonZeroAllelesInd[4] = {0, 0, 0, 0};
        for (int i = 0; i <= 3; i++)
        {
 	    myCountAlleles[i] = myNumAllelesFilter[i];
    	    if (myNumAllelesFilter[i] != 0)
	    { 
	        NonZeroAlleles[NumNonZeroAlleles] = i;
	      //NonZeroAllelesInd[i] = 1;
                NumNonZeroAlleles++;
	    }
        }
	//std::cout << "\tNumNonZeroAlleles:" << NumNonZeroAlleles;
	tempStr.append("\tNumNonZeroAllelesFilter:");
	sprintf(tempCStr, "%d", NumNonZeroAlleles);
	tempStr.append(tempCStr);

        int indArray[15][4] = {{1,0,0,0},
                               {0,1,0,0},
                               {0,0,1,0},
                               {0,0,0,1},
                               {1,1,0,0},
                               {1,0,1,0},
                               {1,0,0,1},
                               {0,1,1,0},
                               {0,1,0,1},
                               {0,0,1,1},
                               {1,1,1,0},
                               {1,1,0,1},
                               {1,0,1,1},
                               {0,1,1,1},
			       {1,1,1,1}};

        // Conditional on the summaryStrand results, this array provides a vector indicating which genotypes should be considered
	/*
        int indexStrandArray[16][15] = {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,1,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,1,0,0,0,0,0,0,0,0,0,0,0},
                                        {1,1,0,0,1,0,0,0,0,0,0,0,0,0,0},
                                        {1,0,1,0,0,1,0,0,0,0,0,0,0,0,0},
                                        {1,0,0,1,0,0,1,0,0,0,0,0,0,0,0},
                                        {0,1,1,0,0,0,0,1,0,0,0,0,0,0,0},
                                        {0,1,0,1,0,0,0,0,1,0,0,0,0,0,0},
                                        {0,0,1,1,0,0,0,0,0,1,0,0,0,0,0},
                                        {1,1,1,0,1,1,0,1,0,0,1,0,0,0,0},
                                        {1,1,0,1,1,0,1,0,1,0,0,1,0,0,0},
                                        {1,0,1,1,0,1,1,0,0,1,0,0,1,0,0},
                                        {0,1,1,1,0,0,0,1,1,1,0,0,0,1,0},
                                        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1} };
	*/

        int indexStrandArray[16][15] = {{1,1,1,1,0,0,0,0,0,0,0,0,0,0,0},
                                        {1,1,1,1,0,0,0,0,0,0,0,0,0,0,0},
                                        {1,1,1,1,0,0,0,0,0,0,0,0,0,0,0},
                                        {1,1,1,1,0,0,0,0,0,0,0,0,0,0,0},
                                        {1,1,1,1,0,0,0,0,0,0,0,0,0,0,0},
                                        {1,1,1,1,1,0,0,0,0,0,0,0,0,0,0},
                                        {1,1,1,1,0,1,0,0,0,0,0,0,0,0,0},
                                        {1,1,1,1,0,0,1,0,0,0,0,0,0,0,0},
                                        {1,1,1,1,0,0,0,1,0,0,0,0,0,0,0},
                                        {1,1,1,1,0,0,0,0,1,0,0,0,0,0,0},
                                        {1,1,1,1,0,0,0,0,0,1,0,0,0,0,0},
                                        {1,1,1,1,1,1,0,1,0,0,1,0,0,0,0},
                                        {1,1,1,1,1,0,1,0,1,0,0,1,0,0,0},
                                        {1,1,1,1,0,1,1,0,0,1,0,0,1,0,0},
                                        {1,1,1,1,0,0,0,1,1,1,0,0,0,1,0},
                                        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1} };
	

	double llk[15];
	double logprior[15];
	double logposterior[15]; // It's -log(posterior)
	double ** alleFreqMatrix = alloc_matrix(15,4);
	
	for (int m = 0; m < 15; m++)
	{
            llk[m] = 999999;
	}

	//double tmpllk[15];
	//double error = 0.005;
	//error = error/3; 
	//the error rate for one allele to be sequenced as a specific other allele
        
	//set the prior
	// Prior 1
	/*
	for (int m = 0; m < 15; m++)
	{
            logprior[m] = -log10(0.01/8);
	}

	for (int i = 0; i <= 3; i++)
	{
	    if (i == baseRefAllele)
	    {
	        logprior[i] = -log10(0.90);
	    }
	    else 
	    {
 	        logprior[i] = -log10(0.015);
		if (i < baseRefAllele)
		{
		    logprior[indexGenotype(backindexGenotype(i)+backindexGenotype(baseRefAllele))] = -log10(0.015);
		}
		else
		{
		    logprior[indexGenotype(backindexGenotype(baseRefAllele)+backindexGenotype(i))] = -log10(0.015);
		}
	    }
	}
	*/

	// Prior 2
	///*
	for (int m = 0; m < 15; m++)
	{
            logprior[m] = -log10(0.01/10);
	}

	for (int i = 0; i <= 3; i++)
	{
	    if (i == baseRefAllele)
	    {
	        logprior[i] = -log10(0.999);
	    }
	    else 
	    {
 	        logprior[i] = -log10(0.01);
		if (i < baseRefAllele)
		{
		    logprior[indexGenotype(backindexGenotype(i)+backindexGenotype(baseRefAllele))] = -log10(0.01);
		}
		else
		{
		    logprior[indexGenotype(backindexGenotype(baseRefAllele)+backindexGenotype(i))] = -log10(0.01);
		}
	    }
	}
        // */

        if (baseRefAllele >= 0 )     // exclude those deletion polymorphisms (still output some contents though, see below in "else")
	{
	    double llkperm = 999999;
	    convertBasesToInt(myBases, myIndex+1);
	    convertQualitiesToError(myQualities, myIndex+1);
	    myIndexGlobal = myIndex+1;
	    for (int perm = 0; perm < 15; perm++)
	    {
            	double * alleFreq=alloc_vector(4);
 	        estimateAlleFreq(myIndex, myCountAlleles, indArray[perm], alleFreq, llkperm);
		// save the alleFreq;
		alleFreqMatrix[perm] = alleFreq;

		if (!(alleFreq[0] < 0 || alleFreq[1] < 0 || alleFreq[2] < 0 || alleFreq[3] < 0 ))
		//exclude one case: 1) alleFreq[0]= -1
		{
		    llk[perm] = llkperm;
		}
	        logposterior[perm] = logprior[perm] + llk[perm];
	    } 

            int maxIndex = 0;
            double minlogposterior = logposterior[0];

    	    for (int perm = 0; perm < 15; perm++)
	    {
		if (logposterior[perm] < minlogposterior)
		{
		    maxIndex = perm;
		    minlogposterior = logposterior[perm];
		}
	    }

	    /*
	    //extra output
	    tempStr.append("\tMax:");
	    sprintf(tempCStr, "%d", maxIndex);
	    tempStr.append(tempCStr);
	    
    	    for (int perm = 0; perm < 15; perm++)
	    {
	      tempStr.append("\tlogllk:");
	      sprintf(tempCStr, "%6.2f", logposterior[perm]);
	      tempStr.append(tempCStr);
	    }
	    */

            std::string predictGeno;
	    // strandInd is the indicator for whether both "F" and "R" strands are included for all alleles of the genotype
	    int strandInd;
	    predictGeno = backindexGenotype(maxIndex);
	    // Even if there are more than 1 allele observed, the predictGeno can still be the same as the baseRefAllele, therefore check below

            if (NumNonZeroAlleles == 0)
	    {
	      tempStr.append("\t0"); // Col28: pass myDepthFilter threshold
	      tempStr.append("\t0"); // Col29: pass "strand check"
	      tempStr.append("\t0"); // Col30: 1-heteroplasmy; 0-homoplasmy
	      tempStr.append("\tGenotype:"); // Col31: predicted genotype
	      tempStr.append("N");
	      tempStr.append("\tFrequency:1.0"); // Col32: corresponding freq
	      tempStr.append("\t1.0"); // Col33: the freq of the most major allele
              tempStr.append("\t0"); // Col34: candidate for homoplasmy if it is called as a heteroplasmy in the first place? (1-Yes)
            }
	    else if (NumNonZeroAlleles == 1)
	    {
		if (NonZeroAlleles[0] == baseRefAllele)
		{
		  /*
		    std::cout << "\t0";
		    std::cout << "\tGenotype:" << NonZeroAlleles[0];
		    std::cout << "\tFrequency:" << "1.0";
		  */
		  tempStr.append("\t0");
		  tempStr.append("\t0");
		  tempStr.append("\t0");
		  tempStr.append("\tGenotype:");
		  tempStr.append(backToAlleleGenotype(backindexGenotype(NonZeroAlleles[0])));
		  tempStr.append("\tFrequency:1.0");
		  tempStr.append("\t1.0");
		  tempStr.append("\t0");
		}
		else
		{
		  /*
	            std::cout << "\t1";
          	    std::cout << "\tGenotype:" << NonZeroAlleles[0];
		    std::cout << "\tFrequency:" << "1.0";
		  */

		  // Set up a threshold for coverage, if coverage <= threshold, won't call a variant
		  if (myDepthFilter >= DepthThreshold)
		  {
		    tempStr.append("\t1");

                    // check strands;
		    strandInd = checkStrand(predictGeno, myStrandInd);
		    tempStr.append("\t");
		    sprintf(tempCStr, "%d", strandInd);
		    tempStr.append(tempCStr);
		    tempStr.append("\t0");
		  }
		  else
		  {
		    tempStr.append("\t0");
		    tempStr.append("\t0");
		    tempStr.append("\t0");
		  }
		  tempStr.append("\tGenotype:");
		  tempStr.append(backToAlleleGenotype(backindexGenotype(NonZeroAlleles[0])));
		  tempStr.append("\tFrequency:1.0");
		  tempStr.append("\t1.0");
		  tempStr.append("\t0");		  
		}
	    } //if (NumNonZeroAlleles == 1)
	    else
	    {
		if (predictGeno != backindexGenotype(baseRefAllele))
		{
 		     /*
		     std::cout << "\t1";
		     //std::cout << "\tmaxIndex:" << maxIndex;
		     std::cout << "\tGenotype:" << predictGeno;
		     std::cout << "\tFrequency:";
		     */
		     if (myDepthFilter >= DepthThreshold)
		     { 
		       tempStr.append("\t1");

                       // check strands;
 		       strandInd = checkStrand(predictGeno, myStrandInd);
		       // when strandInd == 0, maybe the next most likely genotype is still a variant
		       if (strandInd == 0)
		       {
                         // so if predictGeno.length=1, nothing will change, so strandInd remains 0 for homoplasmy (i.e. if the outright most likely genotpye is homoplasmy, strandInd = 0 and will be called as homoplasmy 
                         if (predictGeno.length() >= 2)
			 {
			  double secondminlogposterior = 9999999;  
			  int secondmaxIndex = 0;
			  int indexstrandInd;
			  indexstrandInd = summaryStrand(myStrandInd);
			  if (indexstrandInd > 0 ) // if indexstranInd == 0 (none of the allels pass the strand filter) then do nothing
			  {
            	           for (int perm = 0; perm < 15; perm++)
	                   {
		               if (indexStrandArray[indexstrandInd][perm] == 1 && logposterior[perm] < secondminlogposterior)
		               {
		                   secondmaxIndex = perm;
		                   secondminlogposterior = logposterior[perm];
		               }
	                   }
			   maxIndex = secondmaxIndex;
	                   predictGeno = backindexGenotype(maxIndex);
			   if (predictGeno != backindexGenotype(baseRefAllele))
			   {
			     strandInd = checkStrand(predictGeno, myStrandInd); 

			     if (predictGeno.length() == 1 && strandInd == 0)
			       {
                                 strandInd = -1;
                               }
                               // so if the next most likely genotype is homoplasmy, but the strandInd = 0, then set it to -1 and therefore homoplasmy won't be called

			     if (predictGeno.length() == 1 && myNumAllelesFilter[indexGenotype(predictGeno)] <= myNumAllelesFilter[baseRefAllele])
			     {
			       strandInd = -1;
			     }
			     // deal with cases like this: Ref C, observe 80C, 20T, however, C does not pass strand filter and T passes the filter, in this case, we don't want to call a T homoplasmy.
			     
			   }
			   else
			   {
			     strandInd = -1;
			   }
			  } // if (indexstrandInd > 0)
			 }  // if (predictGeno.length() >= 2)
			
			 /*
                         if (predictGeno.length() >= 2)
			 {
			   double secondminlogposterior = logposterior[0];  // logposterior[0] won't be the minlogposterior
			   int secondmaxIndex = 0;
            	           for (int perm = 0; perm < 15; perm++)
	                   {
		               if (perm != maxIndex && logposterior[perm] < secondminlogposterior)
		               {
		                   secondmaxIndex = perm;
		                   secondminlogposterior = logposterior[perm];
		               }
	                   }
			   maxIndex = secondmaxIndex;
	                   predictGeno = backindexGenotype(maxIndex);
			   if (predictGeno != backindexGenotype(baseRefAllele))
			   {
                               strandInd = checkStrand(predictGeno, myStrandInd);
			   }
			   else
			   {
			       strandInd = -1;
			   }
			 }  // if (predictGeno.length() >= 2)
			 */  
		       } // if (strandInd == 0)
		       tempStr.append("\t");
		       sprintf(tempCStr, "%d", strandInd);
		       tempStr.append(tempCStr);

		       // check if it is a heteroplasmy or not
		       if (predictGeno.length() >= 2)
		       {
		           tempStr.append("\t1");
		       }
		       else 
		       {
                           tempStr.append("\t0");
		       }
		     }
		     else // if (myDepthFilter >= DepthThreshold)
		     {
		       tempStr.append("\t0");
		       tempStr.append("\t0");
		       tempStr.append("\t0");
		     }
		     tempStr.append("\tGenotype:");
             	     tempStr.append(backToAlleleGenotype(predictGeno));
		     tempStr.append("\tFrequency:");

		     double * alleFreqHat = alloc_vector(4);
		     alleFreqHat = alleFreqMatrix[maxIndex];

		     int count = 0;
		     double maxAlleFreq = 0;
		     double maxAlleIndex = 0; // index which allele is the most major allele (i.e. corresponding to the maxAlleFreq)
		     for (int i = 0; i < 4; i++)
		     {
		       if (alleFreqHat[i] > 0)  //ouput alleFreqHat that is greater than 0
			 {
			     if (count == 0)
			     {
			         //std::cout << alleFreqHat[i];
		                 sprintf(tempCStr, "%6.4f", alleFreqHat[i]);
		                 tempStr.append(tempCStr);
				 maxAlleFreq = alleFreqHat[i];
				 maxAlleIndex = i;
			     }
			     else
			     {
			         //std::cout << "/" << alleFreqHat[i];
			         tempStr.append("/");
		                 sprintf(tempCStr, "%6.4f", alleFreqHat[i]);
		                 tempStr.append(tempCStr);
				 if (alleFreqHat[i] > maxAlleFreq)
				 {
				   maxAlleFreq = alleFreqHat[i];
				   maxAlleIndex = i;
				 }
			     }
			     count++;
			 }
		     }
                     sprintf(tempCStr, "\t%6.4f", maxAlleFreq);
		     tempStr.append(tempCStr);

		     if (predictGeno.length() >= 2)
		     {
		       if (maxAlleIndex != baseRefAllele)    // This is saying that if it is called a heteroplasmy in the first place, but does not pass the MAF threshold later, it still can be a homoplasmy, because the major allele is not the reference allele.
		       {
			 tempStr.append("\t1");
		       }
		       else
		       {
			 tempStr.append("\t0");
		       }
		     }
		     else  //if it is not predicted as a heteroplasmy in the first place, then this label will be "0"
		     {
		       tempStr.append("\t0");
		     }

		     //additional print-out
		     //tempStr.append("\t-logposterior:");
		     //sprintf(tempCStr, "%8.4f", logposterior[0]);
		     //tempStr.append(tempCStr);    
		     //for (int i=1; i < 15; ++i)
		     //{
		     //sprintf(tempCStr, ",%8.4f", logposterior[i]);
		     //tempStr.append(tempCStr);
		     //}
		}
		else // if (predictGeno!= backindexGenotype(baseRefAllele))
		{
		  /*
		     std::cout << "\t0";
		     //std::cout << "\tmaxIndex:" << maxIndex;
		     std::cout << "\tGenotype:" << predictGeno;
		     std::cout << "\tFrequency:" << "1.0";
		  */
		     tempStr.append("\t0");
		     tempStr.append("\t0");
		     tempStr.append("\t0");
		     tempStr.append("\tGenotype:");
		     tempStr.append(backToAlleleGenotype(predictGeno));
		     tempStr.append("\tFrequency:1.0");
		     tempStr.append("\t1.0");
		     tempStr.append("\t0");        
		}
	    } // if (NumNonZeroAlleles == 1)

            // add to print out bases and their quality scores.
	    tempStr.append("\tBASE:");
	    sprintf(tempCStr, "%c", myBases[0]);
	    tempStr.append(tempCStr);    
	    for (int i=1; i<=myIndex; ++i)
	    {
		sprintf(tempCStr, ",%c", myBases[i]);
		tempStr.append(tempCStr);
	    }

    	    tempStr.append("\tBASEQ:");
	    sprintf(tempCStr, "%d", myQualities[0]);
	    tempStr.append(tempCStr);    
	    for (int i=1; i<=myIndex; ++i)
	    {
		sprintf(tempCStr, ",%d", myQualities[i]);
		tempStr.append(tempCStr);
	    }

	    tempStr.append("\tStrand:");
            sprintf(tempCStr, "%c", myStrands[0]);
            tempStr.append(tempCStr);
            for (int i=1; i<=myIndex; ++i)
            {
                sprintf(tempCStr, ",%c", myStrands[i]);
                tempStr.append(tempCStr);
            }

	    /*
    	    tempStr.append("\tError:");
	    sprintf(tempCStr, "%f", myError[0]);
	    tempStr.append(tempCStr);    
	    for (int i=1; i<=myIndex; ++i)
	    {
		sprintf(tempCStr, ",%f", myError[i]);
		tempStr.append(tempCStr);
	    }
	    */
    	    //std::cout << "\t" << tempStr;
        }
        else  // if (baseRefAllele >= 0 )
	{
	  /*
	    std::cout << "\t0";
	    std::cout << "\tGenotype:" << "N";
            std::cout << "\tFrequency:" << "1.0" << "\n";
	  */
	    tempStr.append("\t0");
	    tempStr.append("\t0");
	    tempStr.append("\t0");
	    tempStr.append("\tGenotype:N");
	    tempStr.append("\tFrequency:1.0");
	    tempStr.append("\t1.0");
	    tempStr.append("\t0");
	}
        tempStr.append("\n");  	
       	myVcfOutFile->ifwrite(tempStr.c_str(), tempStr.length());
        // finish editing by Jun Ding
    }   // "if(getRefPosition() != UNSET_POSITION && myIndex != -1)"

    //to ensure this does not print when reflushed
    myIndex=-1;

}


void PileupElementSummary::reset(int refPosition)
{	
    // Call the base class.      
    PileupElement::reset(refPosition);

    myIndex = -1;
    reset();
}


void PileupElementSummary::reset(int refPosition, GenomeSequence* refSeq, InputFile* vcfOutFile, bool addDelAsBase, double*** logGLMatrix)
{
    // Assign pointer to myLogGLMatrix
    if (myLogGLMatrix == NULL)
    {
        myLogGLMatrix = logGLMatrix;
    }
		
    // Assign pointer to myRefSeq
    if (myRefSeq == NULL)
    {
        myRefSeq = refSeq;
    }

    // Assign pointer to myVcfOutFile
    if (myVcfOutFile == NULL)
    {
        myVcfOutFile = vcfOutFile;
    }
	
    myAddDelAsBase = addDelAsBase;	
    myRefAllele.clear();
	
    // Call the base class.      
    PileupElement::reset(refPosition);

    myIndex = -1;
    reset();
}

void PileupElementSummary::reset()
{
    for(int i = 0; i <= BaseAsciiMap::baseXIndex; i++)
    {
        myNumAlleles[i] = 0;
    }
    myDepth = 0;

    for(int i = 0; i <= BaseAsciiMap::baseXIndex; i++)
    {
        myNumAllelesFilter[i] = 0;
    }
    myDepthFilter = 0;

    myNumDeletes = 0;

    for (int i = 0; i <= 7; i++)
    {
        myStrandInd[i] = 0;
    }
}

void estimateAlleFreq(int myIndex, int * myCountAlleles, int * indVector, double * alleFreq, double & llk)
{
    int sumAvailn = 0;
    int availAllele = 0;
    for (int i = 0; i < 4; i++)
    {
        alleFreq[i] = 0.0;
	if ( myCountAlleles[i] > 0 && indVector[i] > 0)
	{
            sumAvailn = sumAvailn + myCountAlleles[i] * indVector[i];
	    availAllele++;
	}
    }

    for (int i = 0; i < 4; i++)
    {
	if ( myCountAlleles[i] == 0 && indVector[i] > 0)
	// For one of A/C/G/T: no allele is observed while conditioning on that allele, so it can be degenerated to a simple case
	{
	  alleFreq[0] = -1.0;
	  return;
	}
    }

    if (sumAvailn <= 0)
    {
        alleFreq[0] = -1.0;   // first scenario: sumAvailn = 0, i.e. conditioning on the alleles that have 0 counts in the data
    }
    else
    {
  	int dim = availAllele;
	double point[dim];

        if (availAllele == 1)
	{
	  //estimate allelFreq
	  point[0] = -200;    // extreme small, so alleFreq = 1
	  llk = function(indVector, point, dim);
	  transformTheda(point, alleFreq, dim, indVector);
	}
	else
	{
	  /*
	    // initialize point;
	    int j = 0;
	    for (int i = 0; i < 4; i++)
	    {
		if ( myCountAlleles[i] > 0 && indVector[i] > 0)
		{
		    point[j] = double(myCountAlleles[i])/sumAvailn;
		    j++;
		}
	    }
	  */

            // update point and estimate max llk
	    loop = 0;
	    srand(12345);
	    for (int i = 0; i < dim; i++)
	    {
	      point[i] = (rand()%200-100)/1000.0;
	    }
            llk = amoeba(indVector, point, dim, function, 1e-7);
	    
	    if (loop > 1000)
	    {
	      std::cout << "Error: amoeba does not give the right max likelihood!" << std::endl;
	    }	    

	    // update alleFreq
	    transformTheda(point, alleFreq, dim, indVector);
	}

    } // if sumAvailn <= 0
} 

/*
double computeLLK(double error, int * myCountAlleles, double * alleFreq)
{
    double llk;
    llk = 0;
    for (int i = 0; i < 4; i++)
    {
        llk = llk - myCountAlleles[i]*log10((1-4*error)*alleFreq[i] + error);
    }
    return (llk);
}
*/

int indexGenotype(std::string genotype)
{
    int index;
        if (genotype =="0")
	  index = 0;
        if (genotype =="1")
	  index = 1;
        if (genotype =="2")
	  index = 2;
        if (genotype =="3")
	  index = 3;
        if (genotype =="01")
	  index = 4;
        if (genotype =="02")
	  index = 5;
        if (genotype =="03")
	  index = 6;
        if (genotype =="12")
	  index = 7;
        if (genotype =="13")
	  index = 8;
        if (genotype =="23")
	  index = 9;
        if (genotype =="012")
	  index = 10;
        if (genotype =="013")
	  index = 11;
        if (genotype =="023")
	  index = 12;
        if (genotype =="123")
	  index = 13;
        if (genotype =="0123")
	  index = 14;
    return (index);
}

std::string backindexGenotype(int index)
{
    std::string genotype;
    switch(index)
    {
        case 0:
	  genotype = "0";
	  break;
        case 1:
	  genotype = "1";
	  break;
        case 2:
	  genotype = "2";
	  break;
        case 3:
	  genotype = "3";
	  break;
        case 4:
	  genotype = "0/1";
	  break;
        case 5:
	  genotype = "0/2";
	  break;
        case 6:
	  genotype = "0/3";
	  break;
        case 7:
	  genotype = "1/2";
	  break;
        case 8:
	  genotype = "1/3";
	  break;
        case 9:
	  genotype = "2/3";
	  break;
        case 10:
	  genotype = "0/1/2";
	  break;
        case 11:
	  genotype = "0/1/3";
	  break;
        case 12:
	  genotype = "0/2/3";
	  break;
        case 13:
	  genotype = "1/2/3";
	  break;
        case 14:
	  genotype = "0/1/2/3";
	  break;
        default:
	  genotype = "N";
    }
    return (genotype);
}

std::string backToAlleleGenotype(std::string genotype)
{
  std::string alleleGenotype;
        if (genotype =="0")
	  alleleGenotype = "A";
        else if (genotype =="1")
	  alleleGenotype = "C";
        else if (genotype =="2")
	  alleleGenotype = "G";
        else if (genotype =="3")
	  alleleGenotype = "T";
        else if (genotype =="0/1")
	  alleleGenotype = "A/C";
        else if (genotype =="0/2")
	  alleleGenotype = "A/G";
        else if (genotype =="0/3")
	  alleleGenotype = "A/T";
        else if (genotype =="1/2")
	  alleleGenotype = "C/G";
        else if (genotype =="1/3")
	  alleleGenotype = "C/T";
        else if (genotype =="2/3")
	  alleleGenotype = "G/T";
        else if (genotype =="0/1/2")
	  alleleGenotype = "A/C/G";
        else if (genotype =="0/1/3")
	  alleleGenotype = "A/C/T";
        else if (genotype =="0/2/3")
	  alleleGenotype = "A/G/T";
        else if (genotype =="1/2/3")
	  alleleGenotype = "C/G/T";
        else if (genotype =="0/1/2/3")
	  alleleGenotype = "A/C/G/T";
	else
	  alleleGenotype = "N";
    return (alleleGenotype);
}


// add functions for doing likelihood maximization
double * alloc_vector(int cols)
{
  return (double *) malloc(sizeof(double) * cols);
}

void free_vector(double * vector,int cols)
{
 free(vector);
}

double ** alloc_matrix(int rows,int cols)
{
 int i;
 double ** matrix=(double **) malloc(sizeof(double *) * rows);

 for(i=0;i<rows;i++)
    matrix[i]=alloc_vector(cols);
 return matrix;
}

void free_matrix(double ** matrix,int rows,int cols)
{
  int i;
  for(i=0;i<rows;i++)
    free_vector(matrix[i],cols);
  free(matrix);
}

//Simplex method

double ** make_simplex(double * point,int dim)
{
  int i,j;
  double ** simplex=alloc_matrix(dim+1,dim);

  for(i=0;i<dim+1;i++)
     for(j=0;j<dim;j++)
        simplex[i][j]=point[j];

  for(i=0;i<dim;i++)
     simplex[i][i]+=1.0;

  return simplex;
}


void simplex_extremes(double *fx,int dim,int & ihi,int & ilo,int & inhi)
{
  int i;

  if(fx[0]>fx[1])
    {ihi=0;ilo=inhi=1;}
  else
    {ihi=1;ilo=inhi=0;}

  for(i=2;i<dim+1;i++)
   if(fx[i]<=fx[ilo])
        ilo=i;
     else if(fx[i]>fx[ihi])
        {inhi=ihi;ihi=i;}
     else if(fx[i]>fx[inhi])
         inhi=i;
  
}

void evaluate_simplex(int * indVector,double ** simplex,int dim,double * fx,double (* func)(int *,double *,int))
{
  for(int i=0;i<dim+1;i++)
     fx[i]=(* func)(indVector,simplex[i],dim);
}


void simplex_bearings(double ** simplex,int dim,double * midpoint,double * line,int ihi)
{
  int i,j;
  for(j=0;j<dim;j++)
    midpoint[j]=0.0;

  for(i=0;i<dim+1;i++)
    if(i!=ihi)
       for(j=0;j<dim;j++)
          midpoint[j]+=simplex[i][j];

  for(j=0;j<dim;j++)
  {
    midpoint[j]/=dim;
    line[j]=simplex[ihi][j]-midpoint[j];
  }
}

int update_simplex(int * indVector,double * point,int dim,double & fmax,double * midpoint,double * line,double scale,double (* func)(int *,double *,int))
{
  int i,update=0;double * next=alloc_vector(dim),fx;

  for(i=0;i<dim;i++)
    next[i]=midpoint[i]+scale*line[i];
  fx=(* func)(indVector,next,dim);

  if(fx<fmax)
    {
      for(i=0;i<dim;i++)
         point[i]=next[i];
      fmax=fx;
      update=1;
    }

  free_vector(next,dim);
  return update;
}


void contract_simplex(int * indVector,double ** simplex,int dim,double * fx,int ilo,double (* func)(int *,double *,int))
{
  int i,j;

  for(i=0;i<dim+1;i++)
     if(i!=ilo)
        {
          for(j=0;j<dim;j++)
             simplex[i][j]=(simplex[ilo][j]+simplex[i][j])*0.5;
          fx[i]=(* func)(indVector,simplex[i],dim);
        }
}


int check_tol(double fmax,double fmin,double ftol)
{
  double delta=fabs(fmax-fmin);
  double accuracy=(fabs(fmax)+fabs(fmin))*ftol;

  return (delta<(accuracy+ZEPS));
}


double amoeba(int * indVector,double * point,int dim,double (* func)(int *,double *,int),double tol)
{
  int ihi,ilo,inhi,j;
  double fmin;
  double * fx=alloc_vector(dim+1);
  double * midpoint=alloc_vector(dim);
  double * line=alloc_vector(dim);
  double ** simplex=make_simplex(point,dim);

  evaluate_simplex(indVector,simplex,dim,fx,func);

  while(true)
    {
      simplex_extremes(fx,dim,ihi,ilo,inhi);
      simplex_bearings(simplex,dim,midpoint,line,ihi);

      //Stop when converge
      //or stop when loops exceed 1000 (if has problem with converge,try different initial values)
      if(check_tol(fx[ihi],fx[ilo],tol)||loop>1000) break;

      update_simplex(indVector,simplex[ihi],dim,fx[ihi],midpoint,line,-1.0,func);

      if(fx[ihi]<fx[ilo])
        update_simplex(indVector,simplex[ihi],dim,fx[ihi],midpoint,line,-2.0,func);

      else if(fx[ihi]>=fx[inhi])
        if(!update_simplex(indVector,simplex[ihi],dim,fx[ihi],midpoint,line,0.5,func))
           contract_simplex(indVector,simplex,dim,fx,ilo,func);

       loop++;
    }

  for(j=0;j<dim;j++)
	   point[j]=simplex[ilo][j];
  fmin=fx[ilo];

    free_vector(fx,dim);
    free_vector(midpoint,dim);
    free_vector(line,dim);
    free_matrix(simplex,dim+1,dim);

    return fmin;
}


double function(int * indVector, double * theda, int dim)
{ 
    double l=0.0;
    // l = -log(likelihood), therefore minimization of l = maximization of LLK
    double * transformedTheda = alloc_vector(4);
    transformTheda(theda, transformedTheda, dim, indVector);

    for (int i = 0; i < myIndexGlobal; i++)
    {
      // add one more threshold: quality_score > QSThreshold
      if (myBasesInt[i] >= 0 && myError[i] <= myErrorThreshold+0.000001)
	{
          l = l - log10(transformedTheda[myBasesInt[i]] * (1-4*myError[i]) + myError[i]);
	}
    }
    return l;  //Note: l=-log likelihood, l is nonnegative, we need to minimize l
}

void assignAlleFreq(int * indVector, double * point, int dim, double * alleFreq)
{
  int index = 0;
  for (int i = 0; i < 4; i++)
  {
    if (indVector[i] == 1)
    {
      alleFreq[i] = point[index];
      index++;
    }
    else
    {
      alleFreq[i] = 0;
    }
  }
}

void transformTheda(double * theda, double * transformedTheda, int dim, int * indVector)
{
  double tmpTheda[dim];
  double sum = 0;
  for (int i = 0; i < dim; i++)
    {
      tmpTheda[i] = exp(-exp(theda[i]));
      sum = sum + tmpTheda[i];
    }
  for (int i = 0; i < dim; i++)
    {
      tmpTheda[i] = tmpTheda[i]/sum;
    }

  int count = 0;
  for (int i = 0; i < 4; i++)
    {
      if (indVector[i] == 1)
	{
	  transformedTheda[i] = tmpTheda[count];
	  count++;
        }
      else 
	{
	  transformedTheda[i] = 0.0;
	}
    }

  if (count != dim)
    std::cout << "Error: count is not equal to dim!!" << std::endl;
}

void convertBasesToInt(char * myBases, int myIndex)
{
  for (int i = 0; i < myIndex; i++)
    {
      myBasesInt[i] = switchBasestoInt(myBases[i]);
    }
}

int switchBasestoInt(char charbase)
{
    int base;
    switch(charbase)
    {
	case 'A':
	    base = 0;
	    break;
	case 'C':
	    base = 1;
	    break;
	case 'G':
	    base = 2;
	    break;
	case 'T':
	    base = 3;
	    break;    			
	default :
	    base = -1;
    }
    return(base);
}

void convertQualitiesToError(int8_t * myQualities, int myIndex)
{
  for (int i = 0; i < myIndex; i++)
    {
      if (myQualities[i] > 0)
	{
	  myError[i] = pow(10, -myQualities[i]/10.0)/3.0;
	}
      else
	{
	  myError[i] = 0.80/3.0;
	}
    }
}

int checkStrand(std::string predictGeno, int * myStrandInd)
{
    int strandInd = 0;
        if (predictGeno =="0")
	  { if (myStrandInd[0] + myStrandInd[1] == 2) strandInd = 1; }
        else if (predictGeno =="1")
	  { if (myStrandInd[2] + myStrandInd[3] == 2) strandInd = 1; }
        else if (predictGeno =="2")
	  { if (myStrandInd[4] + myStrandInd[5] == 2) strandInd = 1; }
        else if (predictGeno =="3")
	  { if (myStrandInd[6] + myStrandInd[7] == 2) strandInd = 1; }
        else if (predictGeno =="0/1")
	  { if (myStrandInd[0] + myStrandInd[1] + myStrandInd[2] + myStrandInd[3] == 4) strandInd = 1; }
        else if (predictGeno =="0/2")
	  { if (myStrandInd[0] + myStrandInd[1] + myStrandInd[4] + myStrandInd[5] == 4) strandInd = 1; }
        else if (predictGeno =="0/3")
	  { if (myStrandInd[0] + myStrandInd[1] + myStrandInd[6] + myStrandInd[7] == 4) strandInd = 1; }
        else if (predictGeno =="1/2")
	  { if (myStrandInd[4] + myStrandInd[5] + myStrandInd[2] + myStrandInd[3] == 4) strandInd = 1; }
        else if (predictGeno =="1/3")
	  { if (myStrandInd[6] + myStrandInd[7] + myStrandInd[2] + myStrandInd[3] == 4) strandInd = 1; }
        else if (predictGeno =="2/3")
	  { if (myStrandInd[4] + myStrandInd[5] + myStrandInd[6] + myStrandInd[7] == 4) strandInd = 1; }
        else if (predictGeno =="0/1/2")
	  { if (myStrandInd[0] + myStrandInd[1] + myStrandInd[2] + myStrandInd[3] + myStrandInd[4] + myStrandInd[5] == 6) strandInd = 1; }
        else if (predictGeno =="0/1/3")
	  { if (myStrandInd[0] + myStrandInd[1] + myStrandInd[2] + myStrandInd[3] + myStrandInd[6] + myStrandInd[7] == 6) strandInd = 1; }
        else if (predictGeno =="0/2/3")
	  { if (myStrandInd[0] + myStrandInd[1] + myStrandInd[4] + myStrandInd[5] + myStrandInd[6] + myStrandInd[7] == 6) strandInd = 1; }
        else if (predictGeno =="1/2/3")
	  { if (myStrandInd[6] + myStrandInd[7] + myStrandInd[2] + myStrandInd[3] + myStrandInd[4] + myStrandInd[5] == 6) strandInd = 1; }
        else if (predictGeno =="0/1/2/3")
	  { if (myStrandInd[0] + myStrandInd[1] + myStrandInd[2] + myStrandInd[3] + myStrandInd[4] + myStrandInd[5] + myStrandInd[6] + myStrandInd[7] == 8) strandInd = 1; }
    return (strandInd);
}

int summaryStrand(int * myStrandInd)
{
    int indexstrandInd = 0;
    // if none of the indicators for the 4 alleles is positive, set default indexstrandInd to 0

    if (myStrandInd[0] + myStrandInd[1] == 2) indexstrandInd = 1; 

    if (myStrandInd[2] + myStrandInd[3] == 2) indexstrandInd = 2; 

    if (myStrandInd[4] + myStrandInd[5] == 2) indexstrandInd = 3; 

    if (myStrandInd[6] + myStrandInd[7] == 2) indexstrandInd = 4; 

    if (myStrandInd[0] + myStrandInd[1] + myStrandInd[2] + myStrandInd[3] == 4) indexstrandInd = 5; 

    if (myStrandInd[0] + myStrandInd[1] + myStrandInd[4] + myStrandInd[5] == 4) indexstrandInd = 6; 

    if (myStrandInd[0] + myStrandInd[1] + myStrandInd[6] + myStrandInd[7] == 4) indexstrandInd = 7; 

    if (myStrandInd[4] + myStrandInd[5] + myStrandInd[2] + myStrandInd[3] == 4) indexstrandInd = 8; 

    if (myStrandInd[6] + myStrandInd[7] + myStrandInd[2] + myStrandInd[3] == 4) indexstrandInd = 9; 

    if (myStrandInd[4] + myStrandInd[5] + myStrandInd[6] + myStrandInd[7] == 4) indexstrandInd = 10; 

    if (myStrandInd[0] + myStrandInd[1] + myStrandInd[2] + myStrandInd[3] + myStrandInd[4] + myStrandInd[5] == 6) indexstrandInd = 11; 

    if (myStrandInd[0] + myStrandInd[1] + myStrandInd[2] + myStrandInd[3] + myStrandInd[6] + myStrandInd[7] == 6) indexstrandInd = 12; 

    if (myStrandInd[0] + myStrandInd[1] + myStrandInd[4] + myStrandInd[5] + myStrandInd[6] + myStrandInd[7] == 6) indexstrandInd = 13; 

    if (myStrandInd[6] + myStrandInd[7] + myStrandInd[2] + myStrandInd[3] + myStrandInd[4] + myStrandInd[5] == 6) indexstrandInd = 14; 

    if (myStrandInd[0] + myStrandInd[1] + myStrandInd[2] + myStrandInd[3] + myStrandInd[4] + myStrandInd[5] + myStrandInd[6] + myStrandInd[7] == 8) indexstrandInd = 15; 
    return (indexstrandInd);
}

